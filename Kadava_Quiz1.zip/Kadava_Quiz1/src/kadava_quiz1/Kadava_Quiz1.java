/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package kadava_quiz1;

import java.util.Arrays;
import java.util.Scanner;

/**
 *
 * @author chris
 */
public class Kadava_Quiz1 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        menu();
    }
    
    public static void menu(){
        
        
        
       Scanner scn=new Scanner(System.in);
       System.out.println("[1] oneCode ; ");{
        System.out.println("[2] twocode ;");
         System.out.println("[3] threecode ;");
       
       int input = scn.nextInt();
       
        switch(input){
           case 1:
               one();
               break;
           case 2:
               two();
               break;
           case 3:
               three();
               break;
                
    }
    }
}


    
    public static void one( ){
       
         int[] origArray={82,44,96,7,13,56,74,14,98,36};
        System.out.println( Arrays.toString(origArray));
        
    }
    
    public static void two(){
       int[] origArray={82,44,96,7,13,56,74,14,98,36};
       Scanner scn = new Scanner(System.in);
        System.out.println("enter to delete");
        
        
        
        for(int i = 0; i < origArray.length; i++){
           origArray[i - 1 ] = origArray[i];
       }
       
       int [] newArray = new int [origArray.length - 1 ];
        System.arraycopy(origArray, 0, newArray, 0, origArray.length - 1 );
        
        System.out.println("Array after deleting;");
        for(int num : newArray){
            System.out.println(num +"");
        }
       if(origArray == null || origArray.length == 0){
           System.out.println("Array is empty.");
       }
    }
    
    public static void three(){
        Scanner scanner = new Scanner(System.in);
      
        System.out.println("Enter the elements of the array;");
        int size = scanner.nextInt();
        int []array = new int[size]; 
                
        System.out.println("Enter the number;");
        for(int i = 0; i < size; i++){
            array[i] = scanner.nextInt();
            
        }
        
        System.out.println("Original array;");
        printArray(array);
        
        insertionSort(array);
        System.out.println("sorted");
        printArray(array);
        
        scanner.close();
        
        
        
    
    
    
    
    }
     public static void printArray(int arr[]){
        for (int num : arr){
            System.out.println( num + " ");
}
     }
     
     public static void insertionSort(int arr[]){
        int n = arr.length;
        for(int i = 1; i<n; i++){
            int insert = arr [i];
            int j = i -1 ;
            
            while (j >= 0 && arr[j] > insert){
                arr[j + 1] = arr[j];
                j = j-1;
            }
            arr[j+1]=insert;
        }
     
     
     
}
}


